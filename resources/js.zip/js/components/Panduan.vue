<template>
    <div class="container-fluid">
        <div id="accordion" class="accordion-wrapper mb-3">
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseOne1" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa fa-hand"></i> 1. Panduan Awal</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseOne1" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        <h5 class="font-weight-bold">1. Persiapan</h5>
                        <p>jsdl fjsdflk sdjfl sf</p>
                        <iframe width="100%" height="409" src="https://www.youtube.com/embed/MXNo5tCx6nI" title="LANGKAH DAN PERSIAPAN AWAL TENTANG SOSIAL MEDIA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                        <p>jsdl fjsdflk sdjfl sf</p>
                    </div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-briefcase"></i> 2. Ilmu Bisnis Lainnya</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseOne2" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-12 col-lg-6 col-xs-12">
                                <h5 class="font-weight-bold">Anatomi</h5>
                                <iframe width="100%" height="409" src="https://www.youtube.com/embed/MXNo5tCx6nI" title="LANGKAH DAN PERSIAPAN AWAL TENTANG SOSIAL MEDIA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </div>
                            <div class="col-md-6 col-12 col-lg-6 col-xs-12">
                                <h5 class="font-weight-bold">sdkfsjdk</h5>
                                <button class="btn btn-sm btn-danger">Load Video</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseIlmuBisnis" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-gauge"></i> 3. Quick Hack</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseIlmuBisnis" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-12 col-lg-6 col-xs-12">
                                <h5 class="font-weight-bold">Anatomi</h5>
                                <iframe width="100%" height="409" src="https://www.youtube.com/embed/MXNo5tCx6nI" title="LANGKAH DAN PERSIAPAN AWAL TENTANG SOSIAL MEDIA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </div>
                            <div class="col-md-6 col-12 col-lg-6 col-xs-12">
                                <h5 class="font-weight-bold">sdkfsjdk</h5>
                                <button class="btn btn-sm btn-danger">Load Video</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseOne4" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-book-open"></i> 4. Ada yang bertanya REBI ke Anda ?</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseOne4" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        <div id="exampleAccordion" data-children=".item">
                            <div class="item">
                                <button type="button" aria-expanded="false" aria-controls="exampleAccordion1" data-toggle="collapse" href="#collapseExample" class="m-0 p-0 btn btn-link collapsed">1. AFFILIATE DI REBI SEPERTI APA
                                </button>
                                <div data-parent="#exampleAccordion" id="collapseExample" class="collapse" style="">
                                    <p class="mb-3 alert alert-info">Lorem ipsum dolor
                                        sit amet, consectetur adipiscing elit. Sed pretium lorem
                                        non vestibulum scelerisque. Proin a
                                        vestibulum sem, eget tristique massa. Aliquam lacinia
                                        rhoncus nibh quis ornare.
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <button type="button" aria-expanded="true" aria-controls="exampleAccordion2" data-toggle="collapse" href="#collapseExample2" class="m-0 p-0 btn btn-link">2. AFFILIATE ITU APA
                                </button>
                                <div data-parent="#exampleAccordion" id="collapseExample2" class="collapse" style="">
                                    <p class="mb-3">Donec at ipsum
                                        dignissim, rutrum turpis scelerisque, tristique lectus.
                                        Pellentesque habitant morbi tristique
                                        senectus
                                        et netus et malesuada fames ac turpis egestas. Vivamus
                                        nec dui turpis. Orci varius natoque penatibus et magnis
                                        dis parturient montes, nascetur ridiculus mus.
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseWikiRebi" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-book-bookmark"></i> 5. WikiREBI</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseWikiRebi" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        <div id="exampleAccordionRebi" data-children=".item">
                            <div class="item">
                                <button type="button" aria-expanded="false" aria-controls="exampleAccordion1" data-toggle="collapse" href="#collapseChildRebi2" class="m-0 p-0 btn btn-link collapsed">1. AFFILIATE DI REBI SEPERTI APA
                                </button>
                                <div data-parent="#exampleAccordionRebi" id="collapseChildRebi2" class="collapse" style="">
                                    <p class="mb-3 alert alert-info">Lorem ipsum dolor
                                        sit amet, consectetur adipiscing elit. Sed pretium lorem
                                        non vestibulum scelerisque. Proin a
                                        vestibulum sem, eget tristique massa. Aliquam lacinia
                                        rhoncus nibh quis ornare.
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <button type="button" aria-expanded="true" aria-controls="exampleAccordion2" data-toggle="collapse" href="#collapseChildRebi" class="m-0 p-0 btn btn-link">2. AFFILIATE ITU APA
                                </button>
                                <div data-parent="#exampleAccordionRebi" id="collapseChildRebi" class="collapse" style="">
                                    <p class="mb-3">Donec at ipsum
                                        dignissim, rutrum turpis scelerisque, tristique lectus.
                                        Pellentesque habitant morbi tristique
                                        senectus
                                        et netus et malesuada fames ac turpis egestas. Vivamus
                                        nec dui turpis. Orci varius natoque penatibus et magnis
                                        dis parturient montes, nascetur ridiculus mus.
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseGarisBesar" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-share-from-square"></i> 6. Garis Besar Affiliate REBI</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseGarisBesar" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">g</div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapseTemplate" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-copy"></i> 7. Template</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapseTemplate" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        <div id="accordionTemplate" data-children=".item">
                            <div class="item">
                                <button type="button" aria-expanded="false" aria-controls="exampleAccordion1" data-toggle="collapse" href="#collapseChildRebi2Template" class="m-0 p-0 btn btn-link collapsed">1. AFFILIATE DI REBI SEPERTI APA
                                </button>
                                <div data-parent="#accordionTemplate" id="collapseChildRebi2Template" class="collapse" style="">
                                    <p class="mb-3 alert alert-info">Lorem ipsum dolor
                                        sit amet, consectetur adipiscing elit. Sed pretium lorem
                                        non vestibulum scelerisque. Proin a
                                        vestibulum sem, eget tristique massa. Aliquam lacinia
                                        rhoncus nibh quis ornare.
                                    </p>
                                </div>
                            </div>
                            <div class="item">
                                <button type="button" aria-expanded="true" aria-controls="exampleAccordion2" data-toggle="collapse" href="#collapseChildRebiTemplate" class="m-0 p-0 btn btn-link">2. AFFILIATE ITU APA
                                </button>
                                <div data-parent="#accordionTemplate" id="collapseChildRebiTemplate" class="collapse" style="">
                                    <p class="mb-3">Donec at ipsum
                                        dignissim, rutrum turpis scelerisque, tristique lectus.
                                        Pellentesque habitant morbi tristique
                                        senectus
                                        et netus et malesuada fames ac turpis egestas. Vivamus
                                        nec dui turpis. Orci varius natoque penatibus et magnis
                                        dis parturient montes, nascetur ridiculus mus.
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="">
                <div id="headingOne" class="card-header">
                    <button type="button" data-toggle="collapse" data-target="#collapsePanduan" aria-expanded="false" aria-controls="collapseOne" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                        <h5 class="m-0 p-0"><i class="fa-solid fa-stamp"></i> 8. Ketentuan & Aturan</h5>
                    </button>
                </div>
                <div data-parent="#accordion" id="collapsePanduan" aria-labelledby="headingOne" class="collapse rebi-bg-content" style="">
                    <div class="card-body">
                        wysl
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>
    export default {

    };
</script>
