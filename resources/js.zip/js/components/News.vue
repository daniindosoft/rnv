<template>
    <div class="container-fluid">
        <div id="tab-content-1" role="tabpanel" class="tab-pane tabs-animastion fade active show">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="mb-3 card">
                        <div class="card-body">
                            <ul class="tabs-animated-shadow nav-justified tabs-animated nav">
                                <li class="nav-item">
                                    <a role="tab" class="nav-link active" id="tab-c1-0" data-toggle="tab" href="#tab-animated1-0">
                                    <span class="nav-text">Baru</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a role="tab" class="nav-link" id="tab-c1-1" data-toggle="tab" href="#tab-animated1-1">
                                    <span class="nav-text">Sudah dibaca</span>
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active pt-3" id="tab-animated1-0" role="tabpanel">
                                    <div class="callout">
                                        <h5>REBI v8.8 terbaru</h5>
                                        <p> loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew </p>
                                        <small><i class="fa fa-calendar"></i> 23, Juni 2013</small>
                                        <hr>
                                    </div>
                                    <div class="callout">
                                        <h5>REBI v8.8 terbaru</h5>
                                        <p> loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew </p>
                                        <small><i class="fa fa-calendar"></i> 23, Juni 2013</small>
                                        <hr>
                                    </div>
                                    <div class="callout">
                                        <h5>REBI v8.8 terbaru</h5>
                                        <p> loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew </p>
                                        <small><i class="fa fa-calendar"></i> 23, Juni 2013</small>
                                        <hr>
                                    </div>
                                </div>
                                <div class="tab-pane pt-3" id="tab-animated1-1" role="tabpanel">
                                    <div class="callout">
                                        <h5>REBI v8.8 tesrbaru</h5>
                                        <p> loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew loer ekwj roiwej rlkejrwoeriwjeroiwew </p>
                                        <small><i class="fa fa-calendar"></i> 23, Juni 2013</small>
                                        <hr>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab-animated1-2" role="tabpanel">
                                    <p class="mb-0">It was popularised in the 1960s
                                        with the
                                        release of Letraset sheets containing Lorem
                                        Ipsum
                                        passages, and more recently with desktop
                                        publishing
                                        software like Aldus
                                        PageMaker including versions of Lorem
                                        Ipsum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>

</template>

<script>
    export default {

    };
</script>
