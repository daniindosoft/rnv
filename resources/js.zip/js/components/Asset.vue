<template>
    <div class="container-fluid">
        panduan
    </div>
</template>

<script>
    export default {

    };
</script>
